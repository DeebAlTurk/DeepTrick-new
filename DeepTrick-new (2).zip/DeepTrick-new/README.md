"# DeepTrick" 
<h1>Requirements</h1>
<ul>
  <li>Beautiful Soup</li>
  <li>lxml</li>
</ul>
<h1>How to install</h1>
 <ul>
  <li><code>pip install beautifulsoup4</code></li>
  <li><code>pip install lxml</code></li>
</ul>
